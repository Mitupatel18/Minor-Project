import React, { useState, useEffect } from 'react';
import { useParams } from 'react-router-dom';
import { useStripe, useElements, CardElement } from '@stripe/react-stripe-js';
import axios from 'axios';
import './SingleCampaign.css'

function SingleCampaign() {
  const { campaignId } = useParams(); // Get the campaign ID from the URL
  const stripe = useStripe();
  const elements = useElements();
  const [campaign, setCampaign] = useState(null);
  const [paymentAmount, setPaymentAmount] = useState('');

  useEffect(() => {
    const fetchCampaign = async () => {
      try {
        const res = await axios.get(`http://localhost:5000/api/campaigns/${campaignId}`);
        setCampaign(res.data);
      } catch (error) {
        console.error('Error fetching campaign:', error); // Log the error for debugging
      }
    };

    fetchCampaign();
  }, [campaignId]);

  const handlePayment = async (e) => {
    e.preventDefault(); // Prevent default form submission
    const amount = parseFloat(paymentAmount);

    if (isNaN(amount) || amount <= 0) {
      alert('Please enter a valid amount');
      return;
    }

    try {
      const { data } = await axios.post('http://localhost:5000/api/campaigns/create-payment-intent', {
        amount, // amount in cents
        campaignId: campaignId,
      });

      const result = await stripe.confirmCardPayment(data.clientSecret, {
        payment_method: {
          card: elements.getElement(CardElement),
        },
      });

      if (result.error) {
        console.error(result.error);
      } else if (result.paymentIntent.status === 'succeeded') {
        alert('Payment successful');
        await axios.post('http://localhost:5000/api/campaigns/update-campaign-after-payment', {
          campaignId: campaignId,
          amount,
        });
      }
    } catch (error) {
      console.error(error);
    }
  };

  // if (!campaign) return <div>Loading...</div>;

  return (
    <div className='single-contener'>
      <h3 className='contener-title'>{campaign?.title}</h3>
      <p className='contener-desc'><center className='desc-left'>About</center><span className='desc-right'>{campaign?.description}</span></p>
      <p className='contener-goal'>Total Goal: ${campaign?.goal}</p>
      <p className='goal-update'><span className='contener-raised'>Raised: ${campaign?.raised}</span><span className='contener-goalleft'>Goal Left: ${campaign?.goal - campaign?.raised}</span></p>
      
      <form 
        className='payment-info'
        onSubmit={handlePayment}
      >
        <input
          className='fund'
          type="number"
          placeholder="Enter amount"
          value={paymentAmount}
          onChange={(e) => setPaymentAmount(e.target.value)}
          min="1" // Minimum amount to contribute
          required // Makes the field required
        />
        <CardElement />
        <button className='fund-btn' type="submit">Fund</button>
      </form>
      <hr />
      <br />
      <br />

      <p className='contener-creator'>Creator: {campaign?.creator}</p>
      <p className='contener-contect'>Contact us: <a className='contect-link' href={`mailto:${campaign?.email}`}>{campaign?.email}</a></p>
    </div>
  );
}

export default SingleCampaign;
