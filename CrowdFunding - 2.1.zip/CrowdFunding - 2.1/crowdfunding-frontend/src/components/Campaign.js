import React from 'react';
import { useNavigate } from 'react-router-dom';
import "./Campaign.css"

function Campaign({ campaign }) {
  const navigate = useNavigate();

  const handleViewCampaign = () => {
    navigate(`/campaigns/${campaign._id}`); // Navigate to the single campaign page
  };

  return (
    <>
    <div 
      onClick={handleViewCampaign}
      className='campaign-subcontener'
    >
      <h3 className='campaign-title'>{campaign.title}</h3>
      <p className='campaign-desc'>{campaign.description}{campaign.description}</p>
      <p className='campaign-goal'>Goal: ${campaign.goal}</p>
      <p className='campaign-creator'>Creator: {campaign.creator}</p>
      <span className='end'>See More...</span>
    </div>
    
  </>
  );
}

export default Campaign;
