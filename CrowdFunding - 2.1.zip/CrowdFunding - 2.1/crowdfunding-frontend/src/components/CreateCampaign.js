import React, { useState } from 'react';
import axios from 'axios';
import './CreateCampaign.css'
import Banner from "../assets/banner-bg.png";

function CreateCampaign() {
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [goal, setGoal] = useState('');
  const [creator, setCreator] = useState('');
  const [email, setEmail] = useState('');
  const [identity, setIdentity] = useState('');

  const submitCampaign = async (e) => {
    e.preventDefault();
    await axios.post('http://localhost:5000/api/campaigns', { title, description, goal, creator, email, identity });
    alert('Campaign created!');
  };

  return (
    <div className='new-campaign-contener'>
      <div className='lable-contener'>
        <img src={Banner} alt='Banner' className='img' />
      </div>
      <form className='form-contener' onSubmit={submitCampaign}>
        <span className='heading-2'>New Campaign</span>
        <input
          type="text"
          placeholder="Title"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          className='title'
        />
        <textarea
          type="text"
          rows="4"
          placeholder="Description About Campigns"
          value={description}
          onChange={(e) => setDescription(e.target.value)}
          className='desc'
        />
        <div className='mix'>
          <input
            type="number"
            placeholder="Goal"
            value={goal}
            onChange={(e) => setGoal(e.target.value)}
            className='goal'
          />
          <input
            type="text"
            placeholder="Creator"
            value={creator}
            onChange={(e) => setCreator(e.target.value)}
            className='name'
          />
        </div>
        <input
          type="text"
          placeholder="Creator Email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          className='email'
        />
        <input
          type="text"
          minLength="12"
          maxLength="12"
          placeholder="Creator Aadhar No."
          value={identity}
          onChange={(e) => setIdentity(e.target.value)}
          className='identity'
        />
        <button className='btn' type="submit">Create Campaign</button>
      </form>
    </div>
  );
}

export default CreateCampaign;
