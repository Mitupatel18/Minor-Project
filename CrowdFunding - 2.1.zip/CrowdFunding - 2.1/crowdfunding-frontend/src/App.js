import React, { useState, useEffect } from 'react';
import { BrowserRouter as Router, Route, Routes } from 'react-router-dom';
import axios from 'axios';
import CreateCampaign from './components/CreateCampaign';
import Campaign from './components/Campaign';
import SingleCampaign from './components/SingleCampaign';
import { loadStripe } from '@stripe/stripe-js';
import { Elements } from '@stripe/react-stripe-js';
import { IoLocation } from "react-icons/io5";
import { IoCall } from "react-icons/io5";
import { IoIosMail } from "react-icons/io";
import "./App.css";


const stripePromise = loadStripe('pk_test_51PqvFvIe3TjpzuzVj1zlUrZdJZH21BzSXmlrCrjYhKONnfXNtTq9RQnSAOCEbC2SXoRj2IyBLsCiFgpWxb3dvcT000W8BTgJxG');  // Replace with your Stripe Publishable key

function App() {
  const [campaigns, setCampaigns] = useState([]);

  useEffect(() => {
    const fetchCampaigns = async () => {
      const res = await axios.get('http://localhost:5000/api/campaigns');      
      setCampaigns(res.data);
    };

    fetchCampaigns();
  }, []);

  return (

    <Router>
      <Elements stripe={stripePromise}>
        <div>
          <h1 className='header-1'>Crowdfunding Platform</h1>
          <Routes>
            <Route path="/" element={
              <div>
                <CreateCampaign />
                <div className='campaign-contener'>
                  <span className='campaign-contener-header'>List of Campigns</span>
                  <div className='campaign'>
                  {campaigns.map((campaign) => {
                    // Only render campaigns that have not met their goal
                    if (campaign.raised < campaign.goal) {
                      return (
                        <Campaign key={campaign._id} campaign={campaign} />
                      )   
                    }
                  })}
                  </div>
                </div>         
              </div>
            } />
            <Route path="/campaigns/:campaignId" element={
              <div className='singlecampign-pages'>
                <SingleCampaign />
              </div>
              }
            />
              
          </Routes>
          <div className='footer'>
              <p className='heading-3'>CONTACT US</p>
              <h6 className='heading-text'>Feel Free To Contact</h6>

              <div className='contact-content'>
                <center className='contacts'>
                  <IoLocation className='icon' />
                  <p className='contect-name'>Address</p>
                  <p className='contect-info'>123 Street, Ahmedabad, INDIA</p>
                </center>
                <center className='contacts'>
                  <IoCall className='icon' />
                  <p className='contect-name'>Phone</p>
                  <p className='contect-info'>+91 8566912634</p>
                </center>
                <center className='contacts'>
                  <IoIosMail className='icon' />
                  <p className='contect-name'>Email</p>
                  <p className='contect-info'>crowdfunging@gmail.com</p>
                </center>

              </div>
          </div>
        </div>
      </Elements>
    </Router>
  );
}

export default App;
