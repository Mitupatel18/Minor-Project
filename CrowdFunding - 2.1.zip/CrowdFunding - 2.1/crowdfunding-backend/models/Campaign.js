const mongoose = require('mongoose');

const campaignSchema = new mongoose.Schema({
  title: { type: String, required: true },
  description: { type: String, required: true },
  goal: { type: Number, required: true },
  raised: { type: Number, default: 0 },
  creator: { type: String, required: true },
  email: { type: String, required: true },
  identity: { type: Number, required: true },
  backers: [{ type: String }],
  payment_done:{type: Boolean, default: false}
});

const Campaign = mongoose.model('Campaign', campaignSchema);

module.exports = Campaign;
