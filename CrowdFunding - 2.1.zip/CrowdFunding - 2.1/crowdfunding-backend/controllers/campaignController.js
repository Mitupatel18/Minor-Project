const Campaign = require('../models/Campaign');
const stripe = require('stripe')('sk_test_51PqvFvIe3TjpzuzVKTuELAjutuKy6ct3yBV2LfvtXIo4hd5v5pZpr87c1f6c6hueS6EUSZ6Cy5TmiQnBlhocANzx00CFvJrKJM');

// Create a payment intent for Stripe
exports.createPaymentIntent = async (req, res) => {
  const { amount, campaignId } = req.body;
  try {
    const paymentIntent = await stripe.paymentIntents.create({
      amount: amount * 100, // amount in cents
      currency: 'usd',
    });
    res.json({ clientSecret: paymentIntent.client_secret });
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};

exports.updateCampaignAfterPayment = async (req, res) => {
  const { campaignId, amount } = req.body;

  try {
    // Find the campaign and update the raised amount
    const campaign = await Campaign.findById(campaignId);

    if (campaign) {
      campaign.raised += amount;
      await campaign.save();
      res.json({ message: 'Campaign updated successfully' });
    } else {
      res.status(404).json({ message: 'Campaign not found' });
    }
  } catch (error) {
    console.error(error);
    res.status(500).send('Server Error');
  }
};


// Get a single campaign by ID
exports.getCampaignById = async (req, res) => {
  const { id } = req.params; // Extract the campaign ID from the request parameters
  try {
      const campaign = await Campaign.findById(id);
      if (campaign) {
          res.json(campaign);
      } else {
          res.status(404).json({ message: 'Campaign not found' });
      }
  } catch (error) {
      console.error(error);
      res.status(500).send('Server Error');
  }
};



// Get all campaigns
exports.getCampaigns = async (req, res) => {
  try {
    const campaigns = await Campaign.find();
    res.json(campaigns);
  } catch (error) {
    res.status(500).send('Server Error');
  }
};

// Create a new campaign
exports.createCampaign = async (req, res) => {
  const { title, description, goal, creator, email, identity } = req.body;
  try {
    const newCampaign = new Campaign({ title, description, goal, creator, email, identity });
    await newCampaign.save();
    res.json(newCampaign);
  } catch (error) {
    res.status(500).send('Server Error');
  }
};
