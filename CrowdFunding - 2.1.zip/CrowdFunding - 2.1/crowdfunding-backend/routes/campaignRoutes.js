const express = require('express');
const { 
    getCampaigns, 
    createCampaign,
    createPaymentIntent,
    updateCampaignAfterPayment,
    getCampaignById,
 } = require('../controllers/campaignController');

const router = express.Router();

router.get('/', getCampaigns);
router.get('/:id', getCampaignById);
router.post('/', createCampaign);
router.post('/create-payment-intent', createPaymentIntent);
router.post('/update-campaign-after-payment', updateCampaignAfterPayment);

module.exports = router;
